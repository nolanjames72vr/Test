from entity import Entity
import constants as const
from enum import Enum
import pygame


class Bullet(Entity):

    class BulletDirection(Enum):
        DOWN = 1
        UP = -1

    def __init__(self, pos: list, direction: BulletDirection):
        super().__init__(pos, pygame.image.load(const.Images.BULLET))

        self.direction = direction
        self.collide_rect = None
        self.exp_img = pygame.image.load(const.Images.INVADER_SHOT_EXPL)

    def update(self) -> None:
        self.pos[1] += self.direction.value * const.BULLET_SPEED

    def draw(self, frame: pygame.surface) -> None:
        frame.blit(self.sprite, self.pos)
