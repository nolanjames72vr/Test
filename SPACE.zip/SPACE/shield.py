from typing import Optional, Sequence

from entity import Entity
import constants as const
import pygame


class Shield(Entity):

    def __init__(self, pos: Sequence[int]):
        super().__init__(pos, pygame.image.load(const.Images.SHIELD))

    """
    Transforms coordinates in relation to the game, to coordinates in relation
    to the sprite.
    """
    @staticmethod
    def _sprite_coords(game_coords: Sequence[int], sprite: pygame.Surface,
                       sprite_pos: Sequence[int]) -> Optional[list]:
        sprite_w = sprite.get_rect().width
        sprite_h = sprite.get_rect().height

        dx = game_coords[0] - sprite_pos[0]
        dy = game_coords[1] - sprite_pos[1]

        if 0 <= dx < sprite_w and 0 <= dy < sprite_h:
            return [dx, dy]
        else:
            return None

    def _update_mask(self):
        self.mask = pygame.mask.from_surface(self.sprite)

    def shot_explode(self, coords: Sequence[int],
                     explosion: pygame.Surface) -> None:
        for e_pixel_x in range(explosion.get_size()[0]):
            for e_pixel_y in range(explosion.get_size()[1]):
                if explosion.get_at([e_pixel_x, e_pixel_y]).a > 0:
                    game_coords = [e_pixel_x + coords[0],
                                   e_pixel_y + coords[1]]
                    sprite_coords = self._sprite_coords(game_coords,
                                                        self.sprite, self.pos)
                    if sprite_coords is not None:
                        self.sprite.set_at(sprite_coords, const.TRANSPARENT)
        self._update_mask()

    def update(self) -> None:
        pass
