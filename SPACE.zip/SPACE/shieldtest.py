import pygame
import constants as const
from shield import Shield


def damage_shield(shield):
    shield.shot_explode([101, 101])


screen = pygame.display.set_mode(const.SCREEN_SIZE)
shield = Shield([100, 100])

while True:
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN and event.key == const.Keys.FIRE:
            damage_shield(shield)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            shield.shot_explode(pygame.mouse.get_pos(),
                                pygame.image.load(const.Images.INVADER_SHOT_EXPL))

    shield.update()
    screen.fill(const.BLACK)
    shield.draw(screen)
    pygame.display.flip()
