from entity import Entity
import constants as const
import pygame


class Player(Entity):

    def __init__(self, pos: list):
        super().__init__(pos, pygame.image.load(const.Images.PLAYER))

    def update(self) -> None:
        pass

    def update_player(self, current_input) -> None:
        if current_input.left and not self._at_edge(current_input):
            self.pos[0] -= const.PLAYER_SPEED
        elif current_input.right and not self._at_edge(current_input):
            self.pos[0] += const.PLAYER_SPEED

    def _at_edge(self, current_input) -> bool:
        at_edge = False
        if self.pos[0] == 0 and current_input.left:
            at_edge = True
        elif self.pos[0] == 210 and current_input.right:
            at_edge = True

        return at_edge
