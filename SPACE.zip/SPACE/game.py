import pygame
import constants as const
from machinestate import MachineState
from timedupdate import TimedUpdate
from ui import UI
from engine import Engine
from input import Input


class Game:

    def __init__(self):
        pygame.init()
        self.window = pygame.display.set_mode(self._calc_window_size())
        self.frame = pygame.Surface(const.SCREEN_SIZE)
        self.ui = UI()
        self.engine = Engine()
        self.running = True

        self.machine_state = MachineState()

        self.engine_updater = TimedUpdate(self._update, const.UPDATES_P_SEC)
        self.clock = pygame.time.Clock()

    def run(self) -> None:
        self.engine.start()

        while self.running:
            self.main_loop()
        self._exit()

    def main_loop(self) -> None:
        self.engine_updater.update()
        self._draw()
        self.clock.tick()

    @staticmethod
    def _calc_window_size() -> list:
        return [i * const.SCALE for i in const.SCREEN_SIZE]

    def _update(self) -> None:
        cur_input = Input.get_input()

        if cur_input.quit:
            self.running = False
        else:
            self.engine.update(cur_input)
            self.ui.update(self.machine_state)

    def _draw(self) -> None:
        self._clear_frame()

        self.engine.draw(self.frame)
        self.ui.draw(self.frame)

        scaled = pygame.transform.scale(self.frame, self._calc_window_size())
        self.window.blit(scaled, scaled.get_rect())
        pygame.display.flip()

    def _clear_frame(self) -> None:
        self.frame.fill(const.BLACK)

    @staticmethod
    def _exit() -> None:
        pygame.display.quit()
