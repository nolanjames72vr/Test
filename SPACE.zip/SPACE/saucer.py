from entity import Entity
import pygame


class Saucer(Entity):

    def __init__(self, pos: list):
        # todo add image
        super().__init__(pos, None)

    def update(self) -> None:
        pass

    def draw(self, frame: pygame.surface) -> None:
        pass
