from game import Game
import os
import sys


if __name__ == '__main__':
    game = Game()
    game.run()
