from unittest import TestCase

from engine import Engine
from bullet import Bullet
from invader import Invader


class TestEngine(TestCase):

    def test__collides(self):
        invader = Invader([10, 10], [0, 100])
        bullet = Bullet([15, 15], Bullet.BulletDirection.UP)

        engine = Engine()

        if not engine._collides(invader, bullet):
            self.fail()

    def test_collides(self):
        invader = Invader([10, 10], [0, 100])
        bullet = Bullet([15, 100], Bullet.BulletDirection.UP)

        engine = Engine()

        if engine._collides(invader, bullet):
            self.fail()
