import pygame
from machinestate import MachineState


class UI:

    def draw(self, frame: pygame.surface) -> None:
        pass

    def update(self, machinestate: MachineState) -> None:
        pass
