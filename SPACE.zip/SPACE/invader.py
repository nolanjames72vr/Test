from entity import Entity
import constants as const
import pygame
from enum import Enum


class Invader(Entity):

    class InvaderDirection(Enum):
        LEFT = -1
        RIGHT = 1

    def __init__(self, pos: list, movement_range: list):
        super().__init__(pos, pygame.image.load(const.Images.INVADER1))
        self.x_direction = Invader.InvaderDirection.RIGHT
        self.movement_range = movement_range
        self.sprite = pygame.image.load(const.Images.INVADER1)
        self.just_switched_direction = False

    def _is_outside_range(self) -> bool:
        return self.pos[0] < self.movement_range[0] \
               or self.pos[0] > self.movement_range[1]

    def _switch_direction(self) -> None:
        self.pos[1] += const.INVADER_FALL_SPEED

        if self.x_direction == Invader.InvaderDirection.LEFT:
            self.x_direction = Invader.InvaderDirection.RIGHT
        else:
            self.x_direction = Invader.InvaderDirection.LEFT

        self.just_switched_direction = True

    def update(self) -> None:
        if self._is_outside_range() and not self.just_switched_direction:
            self._switch_direction()
        else:
            self.pos[0] += self.x_direction.value * const.INVADER_SPEED
            self.just_switched_direction = False

    def draw(self, frame: pygame.surface) -> None:
        frame.blit(self.sprite, self.pos)
