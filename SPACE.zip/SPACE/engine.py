from collections import Sequence
from typing import Optional

import pygame

from entity import Entity
from invader import Invader
from shield import Shield
from input import Input
from player import Player
from bullet import Bullet
import constants as const


class Engine:

    def __init__(self):
        self.player = Player([const.PLAYER_SPAWN_X, const.PLAYER_SPAWN_Y])
        self.bullets = []
        self.invaders = []
        self.invader_rows = []
        self.shields = []

        self.invader_index = 0

        self._generate_invaders()
        self._generate_shields()

    def _generate_invaders(self) -> None:
        x = const.INVADER_START_X
        y = const.INVADER_START_Y
        for row_num in range(const.INVADER_ROWS):
            self._generate_invader_row([x, y])
            y += const.INVADER_Y_GAP + const.INVADER_SPRITE_H
        self._order_invaders()

    """
    Orders invaders from by row, then column, so they update in the same
    order as the original game.
    """
    def _order_invaders(self) -> None:
        self.invaders.sort(
            key=lambda i: i.pos[1] * const.INVADERS_PER_ROW + i.pos[0],
            reverse=True
        )

    def _generate_invader_row(self, start_pos: Sequence[int]) -> None:
        x = start_pos[0]
        y = start_pos[1]
        range_start = 0

        row_width = const.INVADER_SPRITE_W * const.INVADERS_PER_ROW
        # width of the area the invader has space to move within
        movement_width = const.SCREEN_SIZE[0] - row_width
        for i in range(const.INVADERS_PER_ROW):
            movement_range = [range_start, range_start + movement_width]
            invader = Invader([x, y], movement_range)
            self.invaders.append(invader)

            range_start += const.INVADER_SPRITE_W
            x += const.INVADER_SPRITE_W

    def _generate_shields(self) -> None:
        x = const.SHIELD_POS[0]
        y = const.SHIELD_POS[1]
        for i in range(const.SHIELD_COUNT):
            self.shields.append(Shield([x, y]))
            x += const.SHIELD_GAP

    def _get_entities(self) -> Sequence[Entity]:
        # return self.bullets + self.invaders \
        return [self.player] + self.bullets + self.invaders \
               + self.invader_rows + self.shields

    def _update_invaders(self) -> None:
        # todo make alien faster when going right if its the last one

        if len(self.invaders):
            self.invaders[self.invader_index].update()
            self.invader_index += 1

            if self.invader_index == len(self.invaders):
                self.invader_index = 0

    @staticmethod
    def _collides(entity1: Entity, entity2: Entity) -> Optional[Sequence]:
        # todo fix - currently ignoring the player in collision checking.
        if entity1 is entity2 or isinstance(entity1, Player) or isinstance(entity2, Player):
            return None

        offset = [entity2.pos[0] - entity1.pos[0],
                  entity2.pos[1] - entity1.pos[1]]
        collision_point = entity1.mask.overlap(entity2.mask, offset)
        if collision_point is None:
            return None

        return [entity1.pos[0] + collision_point[0],
                entity1.pos[1] + collision_point[1]]

    def _mng_bullet_collision(self, bullet: Bullet, entity: Entity,
                              collision_pt: Sequence[int]) -> None:
        if isinstance(entity, Shield):
            exp_pt = self._explosion_pt(collision_pt, bullet)
            entity.shot_explode(exp_pt, bullet.exp_img)
        elif isinstance(entity, Invader):
            self.invaders.remove(entity)
        self.bullets.remove(bullet)

    def _detect_bullet_collisions(self):
        for bullet in self.bullets:
            for entity in self._get_entities():
                collision_pt = self._collides(bullet, entity)
                if collision_pt is not None:
                    self._mng_bullet_collision(bullet, entity, collision_pt)

    def _detect_invader_collisions(self):
        # todo josh - check if invader is colliding with a shield or player
        pass

    def _explosion_pt(self, collision_pt: Sequence[int],
                      bullet: Bullet) -> Sequence[int]:
        x = collision_pt[0] - bullet.exp_img.get_width() // 2
        y = collision_pt[1] - bullet.exp_img.get_height() // 2
        return x, y

    def fire_bullet(self, pos: Sequence[int],
                    direction: Bullet.BulletDirection) -> None:
        self.bullets.append(Bullet(pos, direction))

    def detect_collisions(self):
        self._detect_bullet_collisions()
        self._detect_invader_collisions()

    def start(self) -> None:
        pass

    def draw(self, frame: pygame.surface) -> None:
        for entity in self._get_entities():
            entity.draw(frame)

    def update(self, cur_input: Input) -> None:
        # for testing bullet
        if cur_input.fire:
            # todo fix
            self.bullets.append(Bullet([self.player.pos[0] + 6, self.player.pos[1]], Bullet.BulletDirection.UP))

        if cur_input.start1:
            self.invaders.append(Invader([100, 100]))

        for bullet in self.bullets:
            bullet.update()

        self._update_invaders()

        self.detect_collisions()

        # todo cleanup offscreen bullets

        self.player.update_player(cur_input)

