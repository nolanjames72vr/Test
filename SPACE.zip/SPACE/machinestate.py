class MachineState:

    def __init__(self):
        self.coins = 0
        self.high_score = 0
        self.player1score = None
        self.player2score = None
