from abc import ABC, abstractmethod
import pygame


class Entity(ABC):

    def __init__(self, pos: list, sprite: pygame.Surface):
        self.sprite = sprite
        self.pos = pos
        self.mask = pygame.mask.from_surface(self.sprite)

    @abstractmethod
    def update(self) -> None:
        pass

    def draw(self, frame: pygame.surface) -> None:
        frame.blit(self.sprite, self.pos)
