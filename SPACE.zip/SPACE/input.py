import pygame
import constants as const


class Input:

    def __init__(self):
        # whether key is currently pressed
        self.left = False
        self.right = False

        # whether key was just pressed
        # (meaning key transitioned from up to down)
        self.start1 = False
        self.start2 = False
        self.fire = False
        self.coin = False
        self.tilt = False

        self.quit = False

    def _process_keydown(self, event: pygame.event) -> None:
        if event.key == const.Keys.START1:
            self.start1 = True
        elif event.key == const.Keys.START2:
            self.start2 = True
        elif event.key == const.Keys.FIRE:
            self.fire = True
        elif event.key == const.Keys.COIN:
            self.coin = True
        elif event.key == const.Keys.TILT:
            self.tilt = True

    def _process_keys_pressed(self) -> None:
        keys_pressed = pygame.key.get_pressed()
        if keys_pressed[const.Keys.LEFT]:
            self.left = True
        if keys_pressed[const.Keys.RIGHT]:
            self.right = True

    # I couldn't get type hinting to work here. I think it was because
    # it's a class method?
    @classmethod
    def get_input(cls):
        i = cls()
        i._process_keys_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                i.quit = True
            elif event.type == pygame.KEYDOWN:
                i._process_keydown(event)
        return i

    def __str__(self) -> str:
        return f"Left: {self.left}, Right: {self.right}, " \
               f"Start1: {self.start1}, Start2: {self.start2}, " \
               f"Fire: {self.fire}, Coin: {self.coin}, " \
               f"Tilt: {self.tilt}"

    def __repr__(self) -> str:
        return self.__str__()
