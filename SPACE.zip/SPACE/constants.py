import pygame


class Keys:

    LEFT = pygame.K_a
    RIGHT = pygame.K_d

    START1 = pygame.K_1
    START2 = pygame.K_2
    FIRE = pygame.K_j
    COIN = pygame.K_5
    TILT = pygame.K_t

    # todo figure out what keys we need to assign.
    #  I copied the keys used in the si78c repo
    DIP6 = 128
    DIP7 = 256
    SPECIAL1 = 512
    SPECIAL2 = 1024
    QUIT = 2048


class Images:

    BULLET = "bullet.png"
    INVADER1 = "invader1_1.png"
    PLAYER = "player.png"
    SHIELD = "shield.png"
    INVADER_SHOT_EXPL = "AShotExplo.png"


BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
TRANSPARENT = (0, 0, 0, 0)

SCREEN_SIZE = (224, 256)
SCALE = 2

# speed of bullets in pixels/frame
BULLET_SPEED = 1

# speed of invader in pixels/frame
INVADER_SPEED = 2

# speed of Player in pixels/frame
PLAYER_SPEED = 2

# number of pixels to descend when invader reaches edge of screen
INVADER_FALL_SPEED = 8

INVADERS_PER_ROW = 11
INVADER_ROWS = 5

INVADER_X_GAP = 0  # verified correct
INVADER_Y_GAP = 8  # verified correct
INVADER_START_Y = 78  # todo verify
INVADER_START_X = 20  # todo verify
INVADER_SPRITE_W = 16  # todo maybe change?
INVADER_SPRITE_H = 8

SHIELD_POS = [32, 192]
SHIELD_GAP = 45
SHIELD_COUNT = 4

INVADER_ROW_WIDTH = 172

# the number of times the update function should be called per sec
UPDATES_P_SEC = 60

# Player spawn point
PLAYER_SPAWN_X = 100
PLAYER_SPAWN_Y = 216
